---
name: Royal Trivia Arabic
colors:
  surface: '#101127'
  surface-dim: '#101127'
  surface-bright: '#36374f'
  surface-container-lowest: '#0b0c22'
  surface-container-low: '#181930'
  surface-container: '#1d1e34'
  surface-container-high: '#27283f'
  surface-container-highest: '#32334a'
  on-surface: '#e1e0ff'
  on-surface-variant: '#cac3d8'
  inverse-surface: '#e1e0ff'
  inverse-on-surface: '#2d2e46'
  outline: '#948ea1'
  outline-variant: '#494455'
  surface-tint: '#cdbdff'
  primary: '#cdbdff'
  on-primary: '#370095'
  primary-container: '#6c3ce9'
  on-primary-container: '#e4daff'
  inverse-primary: '#6836e5'
  secondary: '#b5c4ff'
  on-secondary: '#00297a'
  secondary-container: '#044dd3'
  on-secondary-container: '#c3cfff'
  tertiary: '#ffba20'
  on-tertiary: '#412d00'
  tertiary-container: '#825c00'
  on-tertiary-container: '#ffda9c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e8deff'
  primary-fixed-dim: '#cdbdff'
  on-primary-fixed: '#20005f'
  on-primary-fixed-variant: '#4f07cd'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b5c4ff'
  on-secondary-fixed: '#00174d'
  on-secondary-fixed-variant: '#003dab'
  tertiary-fixed: '#ffdea8'
  tertiary-fixed-dim: '#ffba20'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5e4200'
  background: '#101127'
  on-background: '#e1e0ff'
  surface-variant: '#32334a'
typography:
  headline-xl:
    fontFamily: Rubik
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 48px
  headline-xl-mobile:
    fontFamily: Rubik
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 38px
  headline-lg:
    fontFamily: Rubik
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 34px
  headline-sm:
    fontFamily: Rubik
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Rubik
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 30px
  body-md:
    fontFamily: Rubik
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-sm:
    fontFamily: Rubik
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label-lg:
    fontFamily: Rubik
    fontSize: 15px
    fontWeight: '700'
    lineHeight: 20px
  label-md:
    fontFamily: Rubik
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  label-sm:
    fontFamily: Rubik
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1.25rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system powers an interactive, gamified Arabic educational quiz application. The visual tone balances joyful playfulness with academic credibility, ensuring learners of all ages feel motivated, challenged, and rewarded.

### Core Attributes
- **Celebratory & Encouraging:** Interactions prioritize high-frequency positive reinforcement through micro-animations, vibrant badge rewards, and tactile score meters.
- **Culturally Grounded & RTL-Native:** Directionality, typographic balance, and icon placements are constructed right-to-left from the ground up, honoring Arabic script fluidity.
- **Polished Gamification:** Tactile surfaces, layered glowing elevation, and volumetric card elements create a modern game feel without descending into chaotic arcade distraction.

### Visual Aesthetic
A hybrid of **Tactile Neomorphic Playfulness** and **Vibrant Glassmorphism**. Deep royal indigo and luminous purple form atmospheric cosmic backgrounds, while bright emerald greens, ruby feedback states, and metallic gold badges emphasize achievements and scholastic milestones.

## Colors

The palette is engineered for vibrant contrast against a nighttime educational canvas, maximizing legibility and eye comfort during long trivia sessions.

### Primary & Secondary (Cosmic Canopy)
- **Primary (`#6C3CE9` - Electric Violet):** Drives hero actions, timer perimeters, active states, and streak counters.
- **Secondary (`#1A56DB` - Royal Azure):** Applied to card backgrounds, level selectors, and secondary progression paths.

### Accents & Gamified Feedback
- **Tertiary / Trophy Gold (`#FFB800`):** Used for XP points, stars, streaks, leaderboard crowns, and the honorary credits badge.
- **Emerald Win (`#10B981`):** Instant validation for correct trivia choices, combo boosts, and upward rank momentum.
- **Crimson Alert (`#EF4444`):** Crisp indication for incorrect choices, depleted lives/hearts, and expiring timers.

### Neutral Foundation
- **Background Root (`#0B0C1E`):** Pure deep night tone.
- **Surface Elevation 1 (`#151736`):** Trivia question panels and category cards.
- **Surface Elevation 2 (`#202452`):** Unselected answer tiles and interactive sheets.
- **Text & Foreground:** High-luminance off-white (`#F8FAFC`) for Arabic display headers, muted periwinkle (`#94A3B8`) for secondary meta-details.

## Typography

The design system uses **Rubik**, a geometric typeface offering native support for Arabic script with proportioned ascenders, descenders, and distinct vowel markings (Tashkeel) crucial for educational clarity.

### Typographic Hierarchy & RTL Rules
- **Line Heights:** Arabic typography requires an expanded line-height (1.4–1.6x font size) compared to Latin equivalents to prevent overlapping diacritics in quiz prompts.
- **Numbers:** Default to Western Arabic numerals (`1, 2, 3`) or Eastern Arabic numerals (`١, ٢, ٣`) depending on the subject curriculum; tabular figure settings ensure dynamic counters and countdown clocks do not cause jitter.
- **Weight Distribution:** Headline questions use `700` and `800` weights to retain clear visual hierarchy under rapid countdown constraints.

## Layout & Spacing

Layout adheres to a 4-column fluid mobile grid anchored within dynamic edge-to-edge safe zones.

### Spatial Rhythm
- **RTL Fluidity:** Horizontal margins, padding, and layout offsets flip intrinsically (`margin-inline-start` and `margin-inline-end`).
- **Interactive Thumb Zone:** Quiz answers and confirmation sheets occupy the lower 55% of the mobile viewport, preventing awkward finger reaches during timed sessions.
- **Vertical Rhythm:** 8px baseline rhythm across components, maintaining predictable vertical stacking for multi-line Arabic question stems.

## Elevation & Depth

Visual depth is achieved through saturated atmospheric glows and multi-tier surface containment rather than muddy neutral shadows.

### Elevation Levels
- **Level 0 (Canvas):** Underlying rich cosmic slate (`#0B0C1E`).
- **Level 1 (Category Cards & Lists):** Surface fill `#151736` with a delicate 1px inset border (`rgba(255, 255, 255, 0.08)`).
- **Level 2 (Interactive Answer Tiles):** `#202452` accented with directional bottom rim shadows (2px to 4px) evoking physical buttons ready to be pressed.
- **Level 3 (Modal Alerts & Question Banners):** Floating frosted surfaces (`rgba(26, 30, 70, 0.85)`) backed by a 16px blur radius and subtle royal blue perimeter luminescence (`0 8px 32px rgba(26, 86, 219, 0.25)`).
- **Celebration Layer (Feedback & Accents):** Correct answer tiles emit an emerald corona (`0 0 20px rgba(16, 185, 129, 0.45)`), while incorrect choices release a momentary ruby outline pulse.

## Shapes

The design system adopts a welcoming, approachable curvature (`roundedness: 2`).

- **Answer Option Cards:** `1rem` (16px) corner radius, conveying a soft yet defined tile.
- **Score Chips & Status Badges:** Fully circular or pill-shaped (`rounded-full` / 9999px) to indicate live status, coin counts, and streak tallies.
- **Category & Header Containers:** `1.5rem` (24px) for prominent visual framing.
- **RTL Symmetrical Balance:** All asymmetrical corner radii (such as conversational speech bubbles or tab selectors) must explicitly mirror their left and right declarations across RTL orientations.

## Components

### Quiz Answer Cards
- **Base State:** High-contrast card with deep blue base, 1px subtle top border glow, flexbox layout displaying the answer letter indicator (أ، ب، ج، د) in an elevated square container on the far right, and the answer text flowing naturally to the left.
- **Active / Pressed State:** Shifts downward by 2px with an inner shadow to simulate a physical push-button.
- **Correct State:** Instant transition to emerald surface (`#065F46`), border `#10B981`, accompanied by an animated checkmark icon.
- **Incorrect State:** Deep crimson backdrop (`#7F1D1D`), border `#EF4444`, with a gentle horizontal shake.

### Gamified Score & Timer Elements
- **Radial Countdown:** Thick circular stroke running clockwise with an animated color interpolation from violet to amber, dropping into crimson during the final 5 seconds.
- **XP / Streak Chip:** Pill-shaped badge featuring an amber gold flame icon, Eastern/Western numeric counter, and semi-translucent dark gold backdrop (`rgba(255, 184, 0, 0.15)`).

### Author & Credits Badge ("إعداد الأستاذ نواف المتيوتي")
- **Visual Design:** An ornamental gold-leaf and royal-blue ribbon card positioned at level intros, summaries, and menu footers.
- **Details:** Encased in a soft glass container with an emerald-and-gold gradient border (`1px solid linear-gradient(135deg, #FFB800, #10B981)`), crowned with an academic cap or quill emblem on the right, and the title typography set in `label-lg` with a high-legibility golden accent.

### Action Buttons
- **Primary CTA:** Saturated violet-to-blue gradient fill (`linear-gradient(90deg, #6C3CE9, #1A56DB)`), crisp bold text, prominent press depth.
- **Secondary CTA:** Frosted translucent surface with bright violet outline and neutral white text.

### Category Chips & Lists
- Compact scrollable horizontal pill lists with active category indicators highlighted in electric purple, providing tactile haptic and visual confirmation on selection.